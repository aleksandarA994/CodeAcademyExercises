var pi = 3.14;
var radius = 25;
var result = pi*radius*radius;
alert(result);