var iphoneNumber=30;
var iphonePrice=899.95;
var customsRate=(iphonePrice)*(5/100);
var taxRate=(iphonePrice)*(18/100);
var result=(iphoneNumber)*(iphonePrice+customsRate+taxRate);
alert(result);